# Dhruv Chavda — Portfolio Website

A responsive, animated, single-page portfolio built with plain HTML, CSS and JavaScript.

## Preview locally
Open `index.html` in a browser.

## Publish free with GitHub Pages
1. Sign in to GitHub and create a new **public** repository named `dhruv-portfolio`.
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then Save.
6. Your free website will appear at `https://YOUR-USERNAME.github.io/dhruv-portfolio/`.

No paid domain or API key is required. The site uses a free GitHub Pages subdomain.
